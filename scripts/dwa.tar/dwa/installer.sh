#!/bin/bash

cd
cp ./Deauth-packets-injection/scripts/dwa/deauth_wireless_attack.sh /etc/
cp ./Deauth-packets-injection/scripts/dwa/dwa /bin/
chmod u+x /bin/dwa
